WHOLE_NUMBERS = '\d+'
DECIMAL_NUMBERS = '\d*\.\d+'
EMAIL = '[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)*@[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)'